//
//  RestaurantTableViewController.h
//  FoodPin
//
//  Created by prom phanit on 2/11/16.
//  Copyright © 2016 promphanit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RestaurantTableViewController : UITableViewController

@end

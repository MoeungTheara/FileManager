//
//  Restaurant.m
//  FoodPin
//
//  Created by prom phanit on 2/25/16.
//  Copyright © 2016 promphanit. All rights reserved.
//

#import "Restaurant.h"

@implementation Restaurant

-(id)init{
    self = [super init];
    if (self) {
        self.name = @"";
        self.image = @"";
    }
    return self;
}


-(id)initWithName:(NSString *)name andImage:(NSString *)image{

    self = [super init];
    if (self) {
        self.name = name;
        self.image = image;
    }
    return self;
}

@end

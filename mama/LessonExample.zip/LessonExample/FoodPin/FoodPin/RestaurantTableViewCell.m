//
//  RestaurantTableViewCell.m
//  FoodPin
//
//  Created by prom phanit on 2/11/16.
//  Copyright © 2016 promphanit. All rights reserved.
//

#import "RestaurantTableViewCell.h"

@implementation RestaurantTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

//
//  Restaurant.h
//  FoodPin
//
//  Created by prom phanit on 2/25/16.
//  Copyright © 2016 promphanit. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Restaurant : NSObject

@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *image;

-(id)initWithName:(NSString *)name andImage:(NSString *)image;

@end

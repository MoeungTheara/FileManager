//
//  RestaurantTableViewController.m
//  FoodPin
//
//  Created by prom phanit on 2/11/16.
//  Copyright © 2016 promphanit. All rights reserved.
//

#import "RestaurantTableViewController.h"
#import "RestaurantTableViewCell.h"
#import "Restaurant.h"

@interface RestaurantTableViewController ()


@property (strong, nonatomic) NSMutableArray *restaurant;


@end

@implementation RestaurantTableViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.restaurant = [[NSMutableArray alloc]init];
    
    Restaurant *restaurant = [[Restaurant alloc]initWithName:@"Cafe Deadend" andImage:@"cafedeadend.jpg"];
    [self.restaurant addObject:restaurant];
    
    restaurant = [[Restaurant alloc]initWithName:@"Homei" andImage:@"homei.jpg"];
    [self.restaurant addObject:restaurant];
    
    restaurant = [[Restaurant alloc]initWithName:@"Teakha" andImage:@"teakha.jpg"];
    [self.restaurant addObject:restaurant];
    
    restaurant = [[Restaurant alloc]initWithName:@"Cafe Loisl" andImage:@"cafeloisl.jpg"];
    [self.restaurant addObject:restaurant];
    
    restaurant = [[Restaurant alloc]initWithName:@"PetiteOyster" andImage:@"petiteoyster.jpg"];
    [self.restaurant addObject:restaurant];
    
    restaurant = [[Restaurant alloc]initWithName:@"For Kee Restaurant" andImage:@"forkeerestaurant.jpg"];
    [self.restaurant addObject:restaurant];
    
    restaurant = [[Restaurant alloc]initWithName:@"Po's Atelier" andImage:@"posatelier.jpg"];
    [self.restaurant addObject:restaurant];
    
    restaurant = [[Restaurant alloc]initWithName:@"Bourke Street Bakery" andImage:@"bourkestreetbakery.jpg"];
    [self.restaurant addObject:restaurant];
    
    restaurant = [[Restaurant alloc]initWithName:@"Haigh's Chocolate" andImage:@"haighschocolate.jpg"];
    [self.restaurant addObject:restaurant];
    
    restaurant = [[Restaurant alloc]initWithName:@"Palomino Espresso" andImage:@"palominoespresso.jpg"];
    [self.restaurant addObject:restaurant];
    
    restaurant = [[Restaurant alloc]initWithName:@"Upstate" andImage:@"upstate.jpg"];
    [self.restaurant addObject:restaurant];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [self.restaurant count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *cellIdentifier = @"cell";
    RestaurantTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    
    Restaurant *restaurant = [self.restaurant objectAtIndex:indexPath.row];
    cell.nameLabel.text = restaurant.name;
    cell.thumbnailImageView.image = [UIImage imageNamed:restaurant.image];
    cell.thumbnailImageView.layer.cornerRadius = 30;
    cell.thumbnailImageView.clipsToBounds = YES;
    
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 80;
}

@end

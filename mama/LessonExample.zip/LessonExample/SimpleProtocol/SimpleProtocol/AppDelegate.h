//
//  AppDelegate.h
//  SimpleProtocol
//
//  Created by prom phanit on 2/24/16.
//  Copyright © 2016 promphanit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


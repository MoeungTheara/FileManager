//
//  ViewController.m
//  SimpleProtocol
//
//  Created by prom phanit on 2/24/16.
//  Copyright © 2016 promphanit. All rights reserved.
//

#import "ViewController.h"
#import "Projector.h"
#import "IOS.h"
#import "Android.h"


@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *textField;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    id <ProjectorDelegate> pro = [[IOS alloc]init];
    [pro display];
    
    pro = [[Android alloc]init];
    [pro display];
    
    self.textField.delegate = self;
    
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField{

    [textField resignFirstResponder];
    
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//
//  Android.m
//  SimpleProtocol
//
//  Created by prom phanit on 2/24/16.
//  Copyright © 2016 promphanit. All rights reserved.
//

#import "Android.h"

@implementation Android

-(void)display{
    NSLog(@"android object implement this method");
}

@end

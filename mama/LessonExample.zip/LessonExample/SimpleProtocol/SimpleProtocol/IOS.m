//
//  IOS.m
//  SimpleProtocol
//
//  Created by prom phanit on 2/24/16.
//  Copyright © 2016 promphanit. All rights reserved.
//

#import "IOS.h"

@implementation IOS

-(void)display{
    NSLog(@"ios object implement this method");
}

@end



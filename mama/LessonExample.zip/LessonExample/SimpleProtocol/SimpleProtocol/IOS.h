//
//  IOS.h
//  SimpleProtocol
//
//  Created by prom phanit on 2/24/16.
//  Copyright © 2016 promphanit. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Projector.h"

@interface IOS : NSObject <ProjectorDelegate>

@end

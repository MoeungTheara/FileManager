//
//  ViewController.h
//  SimpleTable
//
//  Created by prom phanit on 1/30/16.
//  Copyright © 2016 promphanit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>


@end

